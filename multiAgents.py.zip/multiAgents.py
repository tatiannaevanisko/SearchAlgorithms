# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """

    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions

        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        # don't select STOP if there is an equally good option
        if(len(bestIndices) > 1):
            for i in bestIndices:
                if(legalMoves[i] == Directions.STOP):
                    del bestIndices[i]
                    break
        chosenIndex = bestIndices[0] #pick the first one

        "Add more of your code here if you want to"
        #print("get action Amjad")

        return legalMoves[chosenIndex]
    

    def evaluationFunction(self, currentGameState, action):
        """ b
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """

        # ignore STOP, for now
        if(action == Directions.STOP):
            return 0
        # before we generate the new state let's check it that position has food
        # (the new state will 'eat' it if yes)
        oldPos = currentGameState.getPacmanPosition()
        x = oldPos[0]
        y = oldPos[1]
        if(action == Directions.NORTH):
            y += 1
        elif(action == Directions.SOUTH):
            y -= 1
        elif(action == Directions.EAST):
            x += 1
        elif(action == Directions.WEST):
            x -= 1
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition() # (x, y) coordinate on the image
        newFood = successorGameState.getFood() # the whole matrix- showing food position true and blank position false 
        newGhostStates = successorGameState.getGhostStates() # as a list- contains the states of all ghost - each state in form  location and move (x,y)=(2.0, 7.0), West

        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates] #
        
        foodPos = newFood.asList() # get a list of (x,y) coordinate of all of the current dots/food you have on the board
        # add it back to the list so the score is correct
        if(currentGameState.hasFood(x, y)):
            foodPos.append(newPos)
        foodCount = len(foodPos)  # current number of food
        
        foodScore = [manhattanDistance(f, newPos) for f in foodPos]
        #if the ghost is scared view it as very far (i.e. ignore it)
        ghostScore = [manhattanDistance(g.getPosition(), newPos)*(1000 if g.scaredTimer>5 else 1) for g in newGhostStates]
        mf = 1
        if(len(foodScore)):
            mf = min(foodScore)
        if(mf == 0):
            mf = 0.1

        mg = min(ghostScore)
        #don't differentiate between faraway ghosts
        if(mg > 5):
            mg = 5
        score = mg/mf
    
        return score

def scoreEvaluationFunction(currentGameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    #print( currentGameState.getScore())
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """
    def calcNodeValues(self, g, d, a=None, p=None):
        """
        g: game state
        d: maximum ***tree*** depth
        a: action to get here
        p: parent node
        """
        # game tree node description:
        #{value:score, agent:ai, action:a, parent:p, children:[]}
        # score: score at tthe current gameState
        # agent: agent making the moves
        # action: action that took us here
        # parent: parent node
        # children: all the game states resulting from legal moves

        # at any given depth level run through pacman and all the ghosts
        #the tree will be (number of agents)*(requested depth) deep
        na = g.getNumAgents()
        # based on 'd' calculate the agent we are dealing with
        ai = d%na # d modulo (# of agents): e.g. 16%4 == 0 => packman
        #print(g.getPacmanState() if ai == 0 else g.getGhostState(ai))
        d -= 1

        score = self.evaluationFunction(g)
        node = {'value':score, 'agent':ai, 'action':a, 'parent':p, 'children':[]}
        legalActions = g.getLegalActions(ai)
        #if at the requested depth, stop evaluating
        if(d <= 0):
            return node
        for action in legalActions:
            #ignore STOP
            if(action == Directions.STOP):
                continue
            successorGameState = g.generateSuccessor(ai, action)
            #append the children ...
            node['children'].append(self.calcNodeValues(successorGameState, d, action, node))
        # ... and calculate the actual minimax value
        # i.e. pacman maximizes, ghosts minimize
        values = [ch['value'] for ch in node['children']]
        if(len(values)):
            if(ai == 0): # I am pacman
                node['value'] = max(values)
            else: # I am a ghost
                node['value'] = min(values)
        return node


    def getAction(self, gameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        #print("given depth = ",self.depth)
        gameTree = []
        gameTree.append(self.calcNodeValues(gameState, (gameState.getNumAgents()*self.depth)))
        # scan all the first level children and find out which one
        # has the max value. The action to get to that child is the 
        # return value

        # this is just the root
        m = None
        action = None
        for n in gameTree:
            for ch in n['children']:
                if(m is None):
                    m = ch['value']
                    action = ch['action']
                elif(ch['value'] > m):
                    m = ch['value']
                    action = ch['action']
        return action


        #print(gameTree)

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()

def betterEvaluationFunction(currentGameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()

# Abbreviation
better = betterEvaluationFunction
